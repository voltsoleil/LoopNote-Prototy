# LoopNote-Prototype

Prototype PWA d’une application de messagerie audio temporelle.

## Installation

1. Cloner le dépôt
2. python3 -m http.server 8000
3. http://localhost:8000

